import SwiftUI
struct ContentView: View {
    @State var Show = false
    @State var Show1 = false
    @State var Show2 = true
    var body: some View {
        VStack {
            PenShow(ARshow: Show, showPicker: Show1, Transparent: Show2)
        }
    }
}

//Button to show PencilKit
struct PenShow: View {
    @Environment(\.colorScheme) var colorScheme
    @State var ARshow = false
    @State private var isViewOffScreen = true
    @State var showPicker = false
    @State var Transparent = true
    func simpleSuccess() {UINotificationFeedbackGenerator().notificationOccurred(.success)}
    var body: some View {
        Button(action: {self.ARshow.toggle()}){
            Image(systemName: "pencil.circle")
                .font(.title)
        }
        .fullScreenCover(isPresented: $ARshow){
            ZStack{
                VStack{
                    Text("这是内容，可以对这内容进行标记")
                }
                VStack{
                    Button(action: {self.ARshow.toggle(); simpleSuccess()}, label: {
                        HStack{
                            Image(systemName: "chevron.backward.circle")
                                .font(.title)
                            Spacer()
                        }
                    })
                    .padding()
                    Spacer()
                }
                
                // Pencil
                HStack {
                    Spacer()
                    VStack {
                        Button(action: {
                            isViewOffScreen.toggle()
                            self.showPicker.toggle()
                            simpleSuccess()
                        }, label: {
                            Image(systemName: isViewOffScreen ? "circle" : "circle")
                                .font(.title)
                        })
                        .padding()
                        Spacer()
                    }
                }
                .overlay(
                    ZStack {
                        DrawingView(showPicker: $showPicker)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .background(Transparent ? Color(UIColor.systemBackground) : Color.gray.opacity(0))
                            .offset(x: isViewOffScreen ? UIScreen.main.bounds.width : 0)
                            .animation(.easeInOut(duration: 0.5), value: isViewOffScreen)
                    }
                )
                VStack {
                    HStack {
                        if isViewOffScreen {}else{
                            Button(action: { Transparent.toggle() }, label: {
                                Image(systemName: Transparent ? "circle.fill" : "circle")
                                    .font(.title)
                            })
                            .background(Color(UIColor.systemBackground))
                            .cornerRadius(5, antialiased: true)
                        }
                        Spacer()
                        Button(action: { 
                            isViewOffScreen.toggle()
                            self.showPicker.toggle()
                            simpleSuccess()
                        }, label: {
                            Image(systemName: isViewOffScreen ? "pencil.circle" : "pencil.circle.fill")
                                .font(.title)
                        })
                    }
                    .padding()
                    Spacer()
                }
                
                
                
            }
        }
    }
}
